//ferrari image
const ferrari_text = document.querySelector(".list-item-thumb-uper_text1")
const ferrari_img = document.querySelector(".ferrari-img")
//design image
const design_text = document.querySelector(".list-item-thumb-uper_text2")
const design_img = document.querySelector(".design-img")
//ferrari image
ferrari_img.addEventListener("click", () => {
    ferrari_text.classList.toggle("active-text")
})
ferrari_text.addEventListener("click", () => {
    ferrari_text.classList.toggle("active-text")
})
//design image
design_img.addEventListener("click", () => {
    design_text.classList.toggle("active-text")
})
design_text.addEventListener("click", () => {
    design_text.classList.toggle("active-text")
})